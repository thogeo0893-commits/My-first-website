# Vì sao nước biển lại mặn? — Hoạt hình 2D học đường

Clip khởi động Khoa học tự nhiên cho học sinh THCS, chuyển thể từ kịch bản hội thoại Nam, Hùng và Mai do người dùng cung cấp.

- 15 cảnh, 1920 × 1080, 24 fps, 2327 khung hình, dài 96,958 giây.
- Nhân vật anime dạng vector có chu kỳ bước đi, cử động tay, chớp mắt và biểu cảm miệng.
- Bối cảnh đường đến trường tạo riêng; hình minh họa động về biển, muối, ô xy hòa tan và chai nước lọc.
- 20 trang lời thoại tiếng Việt, có tệp SRT đi kèm.
- Nhạc nền được tổng hợp riêng trong dự án. **Bản này chưa có lồng tiếng.**

## Mở dự án

Cài Node.js theo yêu cầu trong package.json (Node.js 24 được dùng để kiểm tra), sau đó chạy:

```sh
npm ci
npm run dev -- --no-open
```

Chọn composition `AnimeKhoiDong`. Mỗi cảnh cũng được đăng ký riêng trong thư mục `Canh` để chỉnh sửa độc lập. Lời thoại nằm trực tiếp trên các node `BasicCaptions` trong `src/scenes`.

## Xuất MP4

```sh
npx remotion render src/index.ts AnimeKhoiDong final-video.mp4 --codec=h264 --audio-codec=aac --audio-bitrate=160k --video-bitrate=4M --pixel-format=yuv420p
```

Môi trường đám mây dùng thêm `--browser-executable=/usr/bin/chromium --concurrency=3`; đường dẫn Chromium này phụ thuộc máy.

## Nội dung giáo dục

- Giữ lại suy đoán của Nam về chai nước lọc dưới nhãn **Ý kiến của Nam** và dấu hỏi; không trình bày đó như kết luận đúng.
- Thay ý “không bao giờ chết đuối” bằng cách diễn đạt chính xác hơn: dễ nổi hơn vẫn có nguy cơ đuối nước.
- Làm rõ Biển Chết là hồ nước mặn.
- Kết thúc bằng câu hỏi mở về chất tinh khiết và hỗn hợp để lớp thảo luận với giáo viên.

## Tệp và công cụ dựng

`story.json` lưu kịch bản chuyển thể và thời lượng từng cảnh. `captions.json` và `subtitles.srt` dùng mốc thời gian toàn video. Các tài nguyên để mở lại dự án đều nằm trong `public`.

`scripts/build-story.py` dựng lại toàn bộ các tệp trong `src/scenes` và `src/Root.tsx` từ kịch bản trong script. **Không chạy lại sau khi chỉnh sửa thủ công nếu chưa sao lưu**, vì các tệp đó sẽ bị ghi lại.

`scripts/generate-music.py` cần NumPy để tái tạo nhạc nền; không cần NumPy để mở hoặc render dự án vì WAV đã được cung cấp.

Không cần API hoặc dịch vụ nhận dạng giọng nói để mở và render phiên bản hiện tại. Lồng tiếng là bước bổ sung riêng, chưa được thực hiện.
