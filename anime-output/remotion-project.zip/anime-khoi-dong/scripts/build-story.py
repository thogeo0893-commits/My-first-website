from pathlib import Path
import json,math,re
root=Path(__file__).resolve().parent.parent
story=[
 ('Opening','Mở đầu','Cả nhóm','intro','Trên đường tới lớp', 'Một câu hỏi nhỏ, mở ra một bài học mới.',5.5),
 ('NamTrip','Chuyến đi biển','Nam','beach','Chuyện ngày chủ nhật','Hôm qua chủ nhật mình vừa được bố mẹ cho đi tắm biển đấy các cậu ạ.',None),
 ('NamSea','Cảm giác tắm biển','Nam','beach','Một kỉ niệm thật vui','Cảm giác được đắm mình trong nước biển thích thật.',None),
 ('NamSalt','Vì sao nước biển mặn','Nam','salt-question','Nhưng có một điều lạ…','Nhưng các cậu biết không, trong lúc mải lặn dưới biển, tớ chẳng may uống mấy ngụm nước biển. Trời ơi, sao nó lại mặn chát thế nhỉ?',None),
 ('HungSalt','Muối trong nước biển','Hùng','salt','Hùng có lời giải thích','Đương nhiên rồi vì trong nước biển có nhiều muối bạn ạ.',None),
 ('HungDeadSea','Câu chuyện Biển Chết','Hùng','float','Một vùng biển đặc biệt','Mình còn nghe nói ở những nơi có nước rất mặn như Biển Chết, người ta thường dễ nổi trên mặt nước hơn.',None),
 ('HungSafety','Dễ nổi hơn vẫn cần an toàn','Hùng','safety','Dễ nổi hơn có nghĩa là gì?','Nhưng dễ nổi hơn không có nghĩa là không thể bị đuối nước nhé!',None),
 ('MaiWish','Điều Mai tò mò','Mai','wonder','Mai cũng rất tò mò','Thú vị vậy ạ? Ước gì mình có dịp được đến đó một lần nhỉ?',None),
 ('MaiOxygen','Trong nước biển còn gì nữa','Mai','oxygen','Không chỉ có muối?','Nhưng mình nghĩ trong nước biển ngoài muối thì sẽ còn có những chất khác, chẳng hạn như khí ô xy thì các sinh vật mới hô hấp được chứ nhỉ?',None),
 ('NamRealizes','Nam nghĩ mình đã hiểu','Nam','sea-mixture','Nam thử kết nối các ý','Tớ hiểu rồi! Vậy nước biển không phải là nước nguyên chất rồi.',None),
 ('NamBottle','Chai nước lọc của Nam','Nam','bottle','Một dự đoán của Nam','Chỉ có chai nước lọc này của mình là nước nguyên chất thôi đúng không các bạn?',None),
 ('HungAgrees','Hùng đồng tình','Hùng','agree','Hùng nghĩ sao?','Tớ cũng nghĩ giống Nam đấy.',None),
 ('MaiDoubt','Mai chưa chắc chắn','Mai','doubt','Khoan đã, có chắc không?','Tớ cũng không dám khẳng định chắc chắn điều này.',None),
 ('MaiClass','Cùng đến lớp tìm hiểu','Mai','school','Cùng tìm lời giải đáp','À, tớ nhớ ra rồi, hôm nay lớp mình có giờ học Khoa học tự nhiên. Vậy chúng mình đến lớp cùng trao đổi với các bạn và nhờ cô giáo giải đáp nhé!',None),
 ('Question','Câu hỏi cho cả lớp','Cả lớp','outro','Đến lượt chúng mình!','Theo em, bạn Nam đã đúng chưa? Nước biển và nước lọc: chất tinh khiết hay hỗn hợp?',9),
]
# Each JSON entry is a Caption, timed for comfortable silent reading.
def chunk(text,max_len=86):
 words=text.split(); result=[]; cur=[]
 for word in words:
  if cur and len(' '.join(cur+[word]))>max_len:
   result.append(' '.join(cur));cur=[]
  cur.append(word)
  if re.search(r'[.!?]$',word) and len(' '.join(cur))>26:
   result.append(' '.join(cur));cur=[]
 if cur: result.append(' '.join(cur))
 return result
all_srt=[]; data=[];offset=0
for ident,name,speaker,mode,heading,text,fixed in story:
 pages=chunk(text)
 lengths=[max(2.9,len(p.split())/3.8+.8) for p in pages]
 duration=fixed or (sum(lengths)+.5)
 frames=math.ceil(duration*24)
 if fixed: lengths=[(frames/24-.6)/len(pages)]*len(pages)
 caps=[];start=.35
 for page,length in zip(pages,lengths):
  end=min(start+length,frames/24-.12)
  cap={'text':page,'startMs':round(start*1000),'endMs':round(end*1000),'timestampMs':None,'confidence':None,'pageBreakAfter':True}
  caps.append(cap);all_srt.append({**cap,'startMs':cap['startMs']+offset,'endMs':cap['endMs']+offset})
  start=end
 scene={'id':ident,'name':name,'speaker':speaker,'mode':mode,'heading':heading,'text':text,'frames':frames,'duration':frames/24,'captions':caps}
 data.append(scene)
 code='''import {useVideoConfig} from 'remotion';
import {DialogueScene} from '../DialogueScene';
import {BasicCaptions} from '../basic-captions';
export const IDENT = () => {
 const {fps}=useVideoConfig();
 return <><DialogueScene speaker=SPEAKER mode=MODE heading=HEADING/>
 <div className="dialogue-caption"><BasicCaptions name="Lời thoại" premountFor={fps} width={1590} combineTokensWithinMilliseconds={0} style={{position:'absolute',left:165,bottom:90}} captions={CAPTIONS}/></div>
 </>;
};
'''.replace('IDENT',ident).replace('SPEAKER',json.dumps(speaker,ensure_ascii=False)).replace('MODE',json.dumps(mode)).replace('HEADING',json.dumps(heading,ensure_ascii=False)).replace('CAPTIONS',json.dumps(caps,ensure_ascii=False,indent=2))
 (root/'src/scenes'/f'{ident}.tsx').write_text(code)
 offset+=frames/24*1000
(root/'story.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
(root/'src/story-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
imports='\n'.join(f'import {{{s["id"]}}} from "./scenes/{s["id"]}";' for s in data)
root_code='''import {Composition,Folder,Series,AbsoluteFill,useVideoConfig,staticFile,interpolate,useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import './style.css';
'''+imports+'\nexport const MainVideo=()=>{const {fps,durationInFrames}=useVideoConfig();const frame=useCurrentFrame();return <AbsoluteFill><Audio name="Nhạc nền gốc" src={staticFile("classroom-music.wav")} premountFor={fps} volume={interpolate(frame,[0,2*fps,durationInFrames-3*fps,durationInFrames],[0,.8,.8,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}/><Series>\n'
for s in data: root_code+=f'<Series.Sequence name="{s["name"]}" durationInFrames={{{s["frames"]}}} premountFor={{fps}}><{s["id"]}/></Series.Sequence>\n'
root_code+='</Series></AbsoluteFill>};\nexport const RemotionRoot=()=> <><Composition id="AnimeKhoiDong" component={MainVideo} width={1920} height={1080} fps={24} durationInFrames={'+str(sum(s['frames'] for s in data))+'}/><Folder name="Canh">\n'
for s in data:root_code+=f'<Composition id="{s["id"]}" component={{{s["id"]}}} width={{1920}} height={{1080}} fps={{24}} durationInFrames={{{s["frames"]}}}/>\n'
root_code+='</Folder></>;\n'
(root/'src/Root.tsx').write_text(root_code)
def time(ms):
 n=round(ms);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
(root/'subtitles.srt').write_text('\n\n'.join(f'{i+1}\n{time(c["startMs"])} --> {time(c["endMs"])}\n{c["text"]}' for i,c in enumerate(all_srt))+'\n')
(root/'captions.json').write_text(json.dumps(all_srt,ensure_ascii=False,indent=2))
print(f'{len(data)} scenes, {sum(s["frames"] for s in data)} frames, {offset/1000:.2f}s, {len(all_srt)} caption pages.')
