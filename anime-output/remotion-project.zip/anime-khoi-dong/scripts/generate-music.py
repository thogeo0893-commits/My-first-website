from pathlib import Path
import json,wave
import numpy as np
root=Path(__file__).resolve().parent.parent
scenes=json.loads((root/'story.json').read_text());duration=sum(s['frames'] for s in scenes)/24
sr=32000;n=round(duration*sr);audio=np.zeros(n,dtype=np.float64)
beat=60/88
rng=np.random.default_rng(20261102)
def add_note(at,midi,length,level,kind='bell'):
 start=round(at*sr)
 count=min(round(length*sr),n-start)
 if count<=0:return
 t=np.arange(count)/sr
 freq=440*2**((midi-69)/12)
 attack=1-np.exp(-t/0.012)
 env=attack*np.exp(-t/(1.05 if kind=='bell' else 2.8))
 tail=np.minimum(1,(length-t)/.2).clip(0,1)
 tone=np.sin(2*np.pi*freq*t)+.19*np.sin(2*np.pi*freq*2*t)*np.exp(-t/.38)+.06*np.sin(2*np.pi*freq*3*t)
 audio[start:start+count]+=tone*env*tail*level
melody=[72,76,79,76,74,72,69,67,69,72,76,74,72,69,67,64,65,69,72,76,74,72,69,67,67,71,74,79,76,74,72,67]
chords=[[48,55,60,64],[45,52,57,60],[41,48,53,57],[43,50,55,59]]
for b in range(int(duration/beat)+1):
 at=b*beat
 if b%2==0:
  add_note(at,melody[(b//2)%len(melody)],beat*2.7,.075)
 if b%8==0:
  for k,midi in enumerate(chords[(b//8)%4]):add_note(at+k*.07,midi,beat*8,.023,'pad')
 if b%4==2:add_note(at,79,beat,.012)
audio*=np.minimum(np.arange(n)/sr/2,1)*np.minimum((n-np.arange(n))/sr/3,1)
audio=audio.clip(-.8,.8)
# Wide but gentle stereo, with a short decorrelated right channel.
right=audio*.94+np.roll(audio,round(.012*sr))*.06
stereo=np.stack([audio,right],axis=1)
with wave.open(str(root/'public/classroom-music.wav'),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((stereo*32767).astype('<i2').tobytes())
print(f'Original instrumental music: {duration:.3f} seconds; no narration generated.')
