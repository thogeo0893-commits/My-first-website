import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const NamTrip = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Nam"
        mode="beach"
        heading="Chuyện ngày chủ nhật"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Hôm qua chủ nhật mình vừa được bố mẹ cho đi tắm biển đấy các cậu ạ.",
              startMs: 350,
              endMs: 5624,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
