import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const HungSalt = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Hùng"
        mode="salt"
        heading="Hùng có lời giải thích"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Đương nhiên rồi vì trong nước biển có nhiều muối bạn ạ.",
              startMs: 350,
              endMs: 4308,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
