import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const Question = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Cả lớp"
        mode="outro"
        heading="Đến lượt chúng mình!"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Theo em, bạn Nam đã đúng chưa?",
              startMs: 350,
              endMs: 4550,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
            {
              text: "Nước biển và nước lọc: chất tinh khiết hay hỗn hợp?",
              startMs: 4550,
              endMs: 8750,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
