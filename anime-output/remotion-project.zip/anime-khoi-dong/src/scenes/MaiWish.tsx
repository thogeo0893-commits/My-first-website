import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const MaiWish = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene speaker="Mai" mode="wonder" heading="Mai cũng rất tò mò" />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Thú vị vậy ạ? Ước gì mình có dịp được đến đó một lần nhỉ?",
              startMs: 350,
              endMs: 5097,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
