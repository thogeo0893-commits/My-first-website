import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const MaiClass = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Mai"
        mode="school"
        heading="Cùng tìm lời giải đáp"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "À, tớ nhớ ra rồi, hôm nay lớp mình có giờ học Khoa học tự nhiên.",
              startMs: 350,
              endMs: 5361,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
            {
              text: "Vậy chúng mình đến lớp cùng trao đổi với các bạn và nhờ cô giáo giải đáp nhé!",
              startMs: 5361,
              endMs: 10897,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
