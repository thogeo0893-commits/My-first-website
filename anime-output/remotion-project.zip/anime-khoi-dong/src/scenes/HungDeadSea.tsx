import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const HungDeadSea = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Hùng"
        mode="float"
        heading="Một vùng biển đặc biệt"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Mình còn nghe nói ở những nơi có nước rất mặn như Biển Chết, người ta thường dễ nổi",
              startMs: 350,
              endMs: 6150,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
            {
              text: "trên mặt nước hơn.",
              startMs: 6150,
              endMs: 9050,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
