import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const NamSea = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Nam"
        mode="beach"
        heading="Một kỉ niệm thật vui"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Cảm giác được đắm mình trong nước biển thích thật.",
              startMs: 350,
              endMs: 3782,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
