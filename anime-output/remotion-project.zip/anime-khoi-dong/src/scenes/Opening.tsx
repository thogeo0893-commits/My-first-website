import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const Opening = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Cả nhóm"
        mode="intro"
        heading="Trên đường tới lớp"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Một câu hỏi nhỏ, mở ra một bài học mới.",
              startMs: 350,
              endMs: 5250,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
