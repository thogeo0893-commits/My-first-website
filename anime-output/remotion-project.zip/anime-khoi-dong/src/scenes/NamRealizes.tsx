import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const NamRealizes = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Nam"
        mode="sea-mixture"
        heading="Nam thử kết nối các ý"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Tớ hiểu rồi! Vậy nước biển không phải là nước nguyên chất rồi.",
              startMs: 350,
              endMs: 4571,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
