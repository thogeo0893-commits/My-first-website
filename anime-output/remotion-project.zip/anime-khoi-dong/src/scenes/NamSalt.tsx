import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const NamSalt = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Nam"
        mode="salt-question"
        heading="Nhưng có một điều lạ…"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Nhưng các cậu biết không, trong lúc mải lặn dưới biển, tớ chẳng may uống mấy ngụm nước",
              startMs: 350,
              endMs: 5887,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
            {
              text: "biển. Trời ơi, sao nó lại mặn chát thế nhỉ?",
              startMs: 5887,
              endMs: 9318,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
