import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const HungAgrees = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene speaker="Hùng" mode="agree" heading="Hùng nghĩ sao?" />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Tớ cũng nghĩ giống Nam đấy.",
              startMs: 350,
              endMs: 3250,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
