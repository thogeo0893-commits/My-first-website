import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const MaiOxygen = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene speaker="Mai" mode="oxygen" heading="Không chỉ có muối?" />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Nhưng mình nghĩ trong nước biển ngoài muối thì sẽ còn có những chất khác, chẳng hạn",
              startMs: 350,
              endMs: 5624,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
            {
              text: "như khí ô xy thì các sinh vật mới hô hấp được chứ nhỉ?",
              startMs: 5624,
              endMs: 10108,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
