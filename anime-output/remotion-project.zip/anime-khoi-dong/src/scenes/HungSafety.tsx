import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const HungSafety = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Hùng"
        mode="safety"
        heading="Dễ nổi hơn có nghĩa là gì?"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Nhưng dễ nổi hơn không có nghĩa là không thể bị đuối nước nhé!",
              startMs: 350,
              endMs: 4834,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
