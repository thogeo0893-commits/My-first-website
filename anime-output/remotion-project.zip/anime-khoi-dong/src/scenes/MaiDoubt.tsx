import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const MaiDoubt = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Mai"
        mode="doubt"
        heading="Khoan đã, có chắc không?"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Tớ cũng không dám khẳng định chắc chắn điều này.",
              startMs: 350,
              endMs: 3782,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
