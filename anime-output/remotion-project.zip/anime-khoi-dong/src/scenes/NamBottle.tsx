import { useVideoConfig } from "remotion";
import { DialogueScene } from "../DialogueScene";
import { BasicCaptions } from "../basic-captions";
export const NamBottle = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      <DialogueScene
        speaker="Nam"
        mode="bottle"
        heading="Một dự đoán của Nam"
      />
      <div className="dialogue-caption">
        <BasicCaptions
          name="Lời thoại"
          premountFor={fps}
          width={1590}
          combineTokensWithinMilliseconds={0}
          style={{ position: "absolute", left: 165, bottom: 90 }}
          captions={[
            {
              text: "Chỉ có chai nước lọc này của mình là nước nguyên chất thôi đúng không các bạn?",
              startMs: 350,
              endMs: 5624,
              timestampMs: null,
              confidence: null,
              pageBreakAfter: true,
            },
          ]}
        />
      </div>
    </>
  );
};
