import { useCurrentFrame, useVideoConfig } from "remotion";
export type Student = "Nam" | "Hùng" | "Mai";
type Props = {
  name: Student;
  active?: boolean;
  walking?: boolean;
  thinking?: boolean;
  bottle?: boolean;
  phase?: number;
};
const palette = {
  Nam: {
    hair: "#192c45",
    light: "#344967",
    pack: "#1f939d",
    eye: "#33758a",
    skin: "#f7d0ad",
  },
  Hùng: {
    hair: "#493a38",
    light: "#70504a",
    pack: "#de9d48",
    eye: "#855b43",
    skin: "#f3c39e",
  },
  Mai: {
    hair: "#292c45",
    light: "#4a4565",
    pack: "#8e77b7",
    eye: "#866484",
    skin: "#fbd6bc",
  },
};

export const Character = ({
  name,
  active = false,
  walking = false,
  thinking = false,
  bottle = false,
  phase = 0,
}: Props) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const p = palette[name];
  const girl = name === "Mai";
  const walk = Math.sin(t * 5.6 + phase);
  const blink = Math.floor(frame + phase * 13) % 113 < 4;
  const mouth = Math.sin(frame * 0.62 + phase) > -0.15;
  const bodyY = walking ? -Math.abs(walk) * 5 : Math.sin(t * 1.8 + phase) * 1.4;
  const armSwing = walking
    ? walk * 15
    : Math.sin(t * 2 + phase) * (active ? 7 : 2);
  const handAngle = active ? (thinking ? -28 : -18) : 0;
  const outline = "#26394d";
  return (
    <svg
      width="360"
      height="660"
      viewBox="0 0 360 660"
      style={{ overflow: "visible" }}
    >
      <ellipse cx="181" cy="621" rx="85" ry="14" fill="#244255" opacity=".14" />
      <g
        transform={`translate(0 ${bodyY})`}
        stroke={outline}
        strokeWidth="3.4"
        strokeLinejoin="round"
        strokeLinecap="round"
      >
        {girl && (
          <path
            d="M114 97 Q94 116 107 241 Q127 270 145 248 L217 249 Q262 256 257 202 L250 103Z"
            fill={p.hair}
          />
        )}
        <rect x="102" y="235" width="151" height="161" rx="35" fill={p.pack} />
        <path
          d="M113 261Q90 299 104 335M247 261Q270 299 257 335"
          fill="none"
          stroke={p.pack}
          strokeWidth="16"
        />
        {/* Independently rigged legs create the walk cycle. */}
        <g transform={`rotate(${walking ? walk * 10 : 0} 157 395)`}>
          <path
            d={
              girl
                ? "M134 409 L172 409 L168 571 L144 571Z"
                : "M132 380 L177 381 L172 570 L140 570Z"
            }
            fill={girl ? p.skin : "#334664"}
          />
          {girl && (
            <path d="M142 536L170 536L168 584L142 584Z" fill="#fafaf8" />
          )}
          <path
            d="M140 571L171 571L174 598Q164 613 126 604L126 589Z"
            fill="#25364a"
          />
          <path d="M128 602H171" stroke="#8c9eaa" />
        </g>
        <g transform={`rotate(${walking ? -walk * 10 : 0} 207 395)`}>
          <path
            d={
              girl
                ? "M189 409 L227 409 L219 571 L195 571Z"
                : "M185 381 L230 380 L224 570 L193 570Z"
            }
            fill={girl ? p.skin : "#334664"}
          />
          {girl && (
            <path d="M195 536L223 536L220 584L195 584Z" fill="#fafaf8" />
          )}
          <path
            d="M193 571L223 571L233 589L233 603Q203 614 191 599Z"
            fill="#25364a"
          />
          <path d="M194 602H232" stroke="#8c9eaa" />
        </g>
        {/* Rear arm. */}
        <g transform={`rotate(${-armSwing} 118 241)`}>
          <path
            d="M117 235Q96 240 93 266L91 301L124 307L137 260Z"
            fill="#fffdf5"
          />
          <path
            d="M93 299L94 365L106 421Q116 434 124 418L121 359L124 305Z"
            fill={p.skin}
          />
          <path d="M107 405L115 421" fill="none" stroke="#d2997d" />
        </g>
        {/* Uniform and shoulder straps. */}
        <path
          d="M142 211L219 211Q245 222 250 272L235 386Q179 399 124 386L111 267Q116 224 142 211Z"
          fill="#fffdf6"
        />
        <path
          d="M228 264L221 377Q182 391 125 379L124 387Q181 400 235 386L246 269Z"
          fill="#d8e6e5"
          stroke="none"
        />
        <path
          d="M144 206L180 224L218 206L224 225L204 244L180 227L157 245L137 224Z"
          fill="#f7fbfb"
        />
        <path d="M179 228L190 243L181 300L171 243Z" fill="#d66d55" />
        <path d="M180 303V373" fill="none" stroke="#c4d4da" strokeWidth="2" />
        <path
          d="M138 222Q126 257 132 317M222 222Q236 264 226 316"
          fill="none"
          stroke={p.pack}
          strokeWidth="13"
        />
        <path
          d="M142 228Q132 263 136 302M219 229Q229 265 224 302"
          fill="none"
          stroke="#ffffff"
          opacity=".3"
          strokeWidth="3"
        />
        <path
          d="M192 302H221V329Q207 340 192 329Z"
          fill="#f0f6f5"
          stroke="#8aabb5"
          strokeWidth="2"
        />
        <path d="M202 308L211 308L207 320Z" fill="#3a8c9e" stroke="none" />
        {girl && (
          <>
            <path
              d="M126 379L235 379L255 440Q185 455 109 440Z"
              fill="#3b5275"
            />
            <path
              d="M137 388L130 439M159 388L156 445M181 388V445M204 388L209 444M225 388L237 439"
              stroke="#6881a0"
              strokeWidth="2"
            />
          </>
        )}
        {!girl && (
          <path
            d="M127 379Q180 390 234 379L234 394Q181 405 127 394Z"
            fill="#283b58"
          />
        )}
        {/* Front arm, gesture and bottle. */}
        <g transform={`rotate(${armSwing + handAngle} 239 240)`}>
          <path
            d="M237 234Q259 239 265 264L270 298L238 310L224 260Z"
            fill="#fffdf5"
          />
          <path
            d="M240 307L246 357L262 399Q274 412 283 397L271 350L270 299Z"
            fill={p.skin}
          />
          <path d="M267 384L277 400" fill="none" stroke="#d2997d" />
          {bottle && (
            <g transform="translate(257 300) rotate(8)">
              <path
                d="M3 15H27L34 30V97Q16 110-2 97V30Z"
                fill="#b4e0ea"
                fillOpacity=".9"
              />
              <path
                d="M-1 49Q17 58 32 49V96Q16 105-1 96Z"
                fill="#73c1d6"
                opacity=".7"
                stroke="none"
              />
              <rect x="4" y="4" width="23" height="17" rx="3" fill="#dff4f2" />
              <path d="M6 31V85" stroke="white" strokeWidth="4" opacity=".8" />
              <rect
                x="-1"
                y="55"
                width="33"
                height="23"
                fill="#fff9e8"
                stroke="none"
              />
              <path
                d="M15 59Q7 68 16 73Q25 68 15 59"
                fill="#35a2be"
                stroke="none"
              />
            </g>
          )}
        </g>
        <path d="M158 184V214Q179 232 201 214V184" fill={p.skin} />
        <path
          d="M157 184Q180 205 201 185V200Q178 216 158 201Z"
          fill="#d99c80"
          stroke="none"
        />
        {/* Anime face: layered iris, inked lashes, nose and animated mouth. */}
        <ellipse cx="115" cy="133" rx="12" ry="20" fill={p.skin} />
        <ellipse cx="245" cy="133" rx="12" ry="20" fill={p.skin} />
        <path
          d="M117 95Q128 46 180 46Q232 48 244 96L241 145Q232 186 181 206Q134 191 120 152Z"
          fill={p.skin}
        />
        <path
          d="M232 110Q244 157 215 183Q198 200 181 206Q225 192 240 152L244 111Z"
          fill="#e9ac8d"
          stroke="none"
          opacity=".5"
        />
        <ellipse
          cx="137"
          cy="161"
          rx="16"
          ry="6"
          fill="#e7a09b"
          opacity=".35"
          stroke="none"
        />
        <ellipse
          cx="223"
          cy="161"
          rx="16"
          ry="6"
          fill="#e7a09b"
          opacity=".35"
          stroke="none"
        />
        {blink ? (
          <>
            <path
              d="M135 132Q148 142 160 131M200 131Q212 142 225 132"
              fill="none"
              strokeWidth="4"
            />
          </>
        ) : (
          <>
            <path
              d="M134 126Q146 116 161 127L159 145Q146 153 135 143Z"
              fill="#fffdf7"
            />
            <path
              d="M199 127Q211 116 226 126L225 143Q212 153 200 145Z"
              fill="#fffdf7"
            />
            <ellipse cx="149" cy="135" rx="9" ry="13" fill={p.eye} />
            <ellipse cx="212" cy="135" rx="9" ry="13" fill={p.eye} />
            <ellipse
              cx="150"
              cy="135"
              rx="4.3"
              ry="8"
              fill="#203043"
              stroke="none"
            />
            <ellipse
              cx="211"
              cy="135"
              rx="4.3"
              ry="8"
              fill="#203043"
              stroke="none"
            />
            <circle cx="146" cy="130" r="3.5" fill="white" stroke="none" />
            <circle cx="209" cy="130" r="3.5" fill="white" stroke="none" />
            <circle cx="153" cy="141" r="1.7" fill="white" stroke="none" />
            <circle cx="215" cy="141" r="1.7" fill="white" stroke="none" />
            <path
              d="M133 126Q147 117 162 126M198 126Q212 117 227 125"
              fill="none"
              strokeWidth="4.4"
            />
          </>
        )}
        <path
          d={
            thinking
              ? "M135 108L159 111M200 111L224 104"
              : "M135 110Q148 104 159 109M201 109Q214 104 225 110"
          }
          stroke={p.hair}
          strokeWidth="3.3"
          fill="none"
        />
        <path
          d="M180 140L176 154L183 155"
          fill="none"
          stroke="#bb8973"
          strokeWidth="2"
        />
        {active && mouth ? (
          <>
            <ellipse
              cx="181"
              cy="176"
              rx={thinking ? 7 : 10}
              ry={thinking ? 8 : 11}
              fill="#793e4d"
              strokeWidth="2.4"
            />
            <path d="M174 181Q182 177 188 182" fill="#e88990" stroke="none" />
          </>
        ) : (
          <path
            d={
              thinking ? "M174 178Q181 174 188 178" : "M171 174Q181 184 192 174"
            }
            fill="none"
            strokeWidth="2.5"
          />
        )}
        {name === "Hùng" && (
          <g fill="none" stroke="#465665" strokeWidth="2.3">
            <rect x="128" y="120" width="39" height="31" rx="11" />
            <rect x="194" y="120" width="39" height="31" rx="11" />
            <path d="M167 130Q180 124 194 130M119 124L129 128M233 128L244 123" />
          </g>
        )}
        {/* Distinct hair silhouettes and soft cel highlights. */}
        {name === "Nam" && (
          <>
            <path
              d="M114 130L100 98L107 74L98 72L127 47L135 25L154 37L176 18L198 31L225 27L238 52L256 65L248 102L240 127L229 86L209 98L208 72L186 94L174 65L152 94L145 75L125 107Z"
              fill={p.hair}
            />
            <path
              d="M121 71L148 52L160 55M184 43L200 48L224 58"
              fill="none"
              stroke={p.light}
              strokeWidth="6"
            />
          </>
        )}
        {name === "Hùng" && (
          <>
            <path
              d="M114 124Q92 82 119 54Q143 20 192 32Q250 31 252 88L242 123L228 94L225 71Q185 96 138 90L123 112Z"
              fill={p.hair}
            />
            <path
              d="M125 69Q166 39 214 53M129 82Q159 64 190 67"
              fill="none"
              stroke={p.light}
              strokeWidth="6"
            />
          </>
        )}
        {girl && (
          <>
            <path
              d="M114 127Q100 82 120 58Q142 31 178 34Q227 28 246 70L246 130L230 109L221 77L205 98L196 72L181 101L174 74L147 105L137 87L123 126Z"
              fill={p.hair}
            />
            <path
              d="M123 82Q145 53 169 51M201 49Q224 53 232 72"
              fill="none"
              stroke={p.light}
              strokeWidth="6"
            />
            <path
              d="M225 88L234 102L221 108L211 96Z"
              fill="#edb746"
              strokeWidth="2"
            />
            <path d="M222 96L230 101" stroke="#ffde8b" strokeWidth="2" />
          </>
        )}
      </g>
    </svg>
  );
};
