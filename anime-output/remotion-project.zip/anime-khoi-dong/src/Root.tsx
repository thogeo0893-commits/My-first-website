import {
  Composition,
  Folder,
  Series,
  AbsoluteFill,
  useVideoConfig,
  staticFile,
  interpolate,
  useCurrentFrame,
} from "remotion";
import { Audio } from "@remotion/media";
import "./style.css";
import { Opening } from "./scenes/Opening";
import { NamTrip } from "./scenes/NamTrip";
import { NamSea } from "./scenes/NamSea";
import { NamSalt } from "./scenes/NamSalt";
import { HungSalt } from "./scenes/HungSalt";
import { HungDeadSea } from "./scenes/HungDeadSea";
import { HungSafety } from "./scenes/HungSafety";
import { MaiWish } from "./scenes/MaiWish";
import { MaiOxygen } from "./scenes/MaiOxygen";
import { NamRealizes } from "./scenes/NamRealizes";
import { NamBottle } from "./scenes/NamBottle";
import { HungAgrees } from "./scenes/HungAgrees";
import { MaiDoubt } from "./scenes/MaiDoubt";
import { MaiClass } from "./scenes/MaiClass";
import { Question } from "./scenes/Question";
export const MainVideo = () => {
  const { fps, durationInFrames } = useVideoConfig();
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Audio
        name="Nhạc nền gốc"
        src={staticFile("classroom-music.wav")}
        premountFor={fps}
        volume={interpolate(
          frame,
          [0, 2 * fps, durationInFrames - 3 * fps, durationInFrames],
          [0, 0.8, 0.8, 0],
          { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
        )}
      />
      <Series>
        <Series.Sequence name="Mở đầu" durationInFrames={132} premountFor={fps}>
          <Opening />
        </Series.Sequence>
        <Series.Sequence
          name="Chuyến đi biển"
          durationInFrames={139}
          premountFor={fps}
        >
          <NamTrip />
        </Series.Sequence>
        <Series.Sequence
          name="Cảm giác tắm biển"
          durationInFrames={95}
          premountFor={fps}
        >
          <NamSea />
        </Series.Sequence>
        <Series.Sequence
          name="Vì sao nước biển mặn"
          durationInFrames={228}
          premountFor={fps}
        >
          <NamSalt />
        </Series.Sequence>
        <Series.Sequence
          name="Muối trong nước biển"
          durationInFrames={107}
          premountFor={fps}
        >
          <HungSalt />
        </Series.Sequence>
        <Series.Sequence
          name="Câu chuyện Biển Chết"
          durationInFrames={221}
          premountFor={fps}
        >
          <HungDeadSea />
        </Series.Sequence>
        <Series.Sequence
          name="Dễ nổi hơn vẫn cần an toàn"
          durationInFrames={120}
          premountFor={fps}
        >
          <HungSafety />
        </Series.Sequence>
        <Series.Sequence
          name="Điều Mai tò mò"
          durationInFrames={126}
          premountFor={fps}
        >
          <MaiWish />
        </Series.Sequence>
        <Series.Sequence
          name="Trong nước biển còn gì nữa"
          durationInFrames={247}
          premountFor={fps}
        >
          <MaiOxygen />
        </Series.Sequence>
        <Series.Sequence
          name="Nam nghĩ mình đã hiểu"
          durationInFrames={114}
          premountFor={fps}
        >
          <NamRealizes />
        </Series.Sequence>
        <Series.Sequence
          name="Chai nước lọc của Nam"
          durationInFrames={139}
          premountFor={fps}
        >
          <NamBottle />
        </Series.Sequence>
        <Series.Sequence
          name="Hùng đồng tình"
          durationInFrames={82}
          premountFor={fps}
        >
          <HungAgrees />
        </Series.Sequence>
        <Series.Sequence
          name="Mai chưa chắc chắn"
          durationInFrames={95}
          premountFor={fps}
        >
          <MaiDoubt />
        </Series.Sequence>
        <Series.Sequence
          name="Cùng đến lớp tìm hiểu"
          durationInFrames={266}
          premountFor={fps}
        >
          <MaiClass />
        </Series.Sequence>
        <Series.Sequence
          name="Câu hỏi cho cả lớp"
          durationInFrames={216}
          premountFor={fps}
        >
          <Question />
        </Series.Sequence>
      </Series>
    </AbsoluteFill>
  );
};
export const RemotionRoot = () => (
  <>
    <Composition
      id="AnimeKhoiDong"
      component={MainVideo}
      width={1920}
      height={1080}
      fps={24}
      durationInFrames={2327}
    />
    <Folder name="Canh">
      <Composition
        id="Opening"
        component={Opening}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={132}
      />
      <Composition
        id="NamTrip"
        component={NamTrip}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={139}
      />
      <Composition
        id="NamSea"
        component={NamSea}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={95}
      />
      <Composition
        id="NamSalt"
        component={NamSalt}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={228}
      />
      <Composition
        id="HungSalt"
        component={HungSalt}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={107}
      />
      <Composition
        id="HungDeadSea"
        component={HungDeadSea}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={221}
      />
      <Composition
        id="HungSafety"
        component={HungSafety}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={120}
      />
      <Composition
        id="MaiWish"
        component={MaiWish}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={126}
      />
      <Composition
        id="MaiOxygen"
        component={MaiOxygen}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={247}
      />
      <Composition
        id="NamRealizes"
        component={NamRealizes}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={114}
      />
      <Composition
        id="NamBottle"
        component={NamBottle}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={139}
      />
      <Composition
        id="HungAgrees"
        component={HungAgrees}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={82}
      />
      <Composition
        id="MaiDoubt"
        component={MaiDoubt}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={95}
      />
      <Composition
        id="MaiClass"
        component={MaiClass}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={266}
      />
      <Composition
        id="Question"
        component={Question}
        width={1920}
        height={1080}
        fps={24}
        durationInFrames={216}
      />
    </Folder>
  </>
);
