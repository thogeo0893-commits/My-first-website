import {
  AbsoluteFill,
  CanvasImage,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Character } from "./Character";
import { ScienceBubble } from "./ScienceBubble";
type Props = { speaker: string; mode: string; heading: string };
const colors: Record<string, string> = {
  Nam: "#237d8a",
  Hùng: "#b87d36",
  Mai: "#827199",
  "Cả nhóm": "#315766",
  "Cả lớp": "#315766",
};
export const DialogueScene = ({ speaker, mode, heading }: Props) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const intro = mode === "intro",
    outro = mode === "outro";
  const walking = !outro;
  const thinks = ["salt-question", "oxygen", "bottle", "doubt"].includes(mode);
  const p = interpolate(frame, [0, 0.32 * fps], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const positions = intro
    ? [900, 1210, 1510]
    : outro
      ? [40, 360, 680]
      : [90, 495, 900];
  const scale = intro ? 0.82 : outro ? 0.82 : 1.06;
  const top = intro ? 245 : outro ? 240 : 178;
  return (
    <AbsoluteFill
      style={{
        fontFamily: "Classroom",
        overflow: "hidden",
        background: "#dce9de",
      }}
    >
      <CanvasImage
        src={staticFile("school-street.png")}
        premountFor={fps}
        style={{
          position: "absolute",
          inset: -20,
          width: walking && !intro ? 2100 : 1960,
          height: walking && !intro ? 1181 : 1120,
          objectFit: "cover",
          translate: `${walking && !intro ? -t * 7 : Math.sin(t * 0.09) * -12}px 0px`,
        }}
      />
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(180deg,rgba(255,252,239,.38) 0%,rgba(255,252,239,0) 42%,rgba(24,53,53,.09) 100%)",
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 48,
          padding: "12px 23px",
          borderRadius: 12,
          background: "#fffceded",
          color: "#315766",
          fontWeight: 700,
          fontSize: 23,
          letterSpacing: 2,
        }}
      >
        KHỞI ĐỘNG · KHOA HỌC TỰ NHIÊN
      </div>
      {!intro && !outro && (
        <div
          style={{
            position: "absolute",
            left: 85,
            top: 114,
            fontSize: 41,
            fontWeight: 700,
            color: "#23465a",
            textShadow: "0 2px 10px #fff",
          }}
        >
          {heading}
        </div>
      )}
      {intro && (
        <div
          style={{
            position: "absolute",
            left: 78,
            top: 162,
            width: 775,
            padding: "35px 38px",
            borderRadius: "30px 80px 36px 60px",
            background: "rgba(255,251,235,.9)",
            color: "#23465a",
            opacity: p,
            translate: `0 ${interpolate(p, [0, 1], [20, 0])}px`,
            textShadow: "0 3px 12px #fff9",
          }}
        >
          <div style={{ fontSize: 89, fontWeight: 700, lineHeight: 1.2 }}>
            Vì sao
            <br />
            nước biển
            <br />
            <span style={{ color: "#a35d39" }}>lại mặn?</span>
          </div>
          <div style={{ fontSize: 33, marginTop: 28, color: "#436879" }}>
            Câu chuyện trên đường tới lớp
          </div>
        </div>
      )}
      <div style={{ opacity: p }}>
        <div
          style={{
            position: "absolute",
            left: positions[0],
            top,
            scale: `${scale}`,
            transformOrigin: "top left",
            translate: `${walking ? interpolate(frame, [0, 6 * fps], [-32, 16], { extrapolateRight: "clamp" }) : 0}px 0px`,
          }}
        >
          <Character
            name="Nam"
            active={speaker === "Nam"}
            walking={walking}
            thinking={thinks && speaker === "Nam"}
            bottle={mode === "bottle"}
            phase={0}
          />
        </div>
        <div
          style={{
            position: "absolute",
            left: positions[1],
            top: top + 12,
            scale: `${scale * 0.98}`,
            transformOrigin: "top left",
            translate: `${walking ? interpolate(frame, [0, 6 * fps], [-32, 16], { extrapolateRight: "clamp" }) : 0}px 0px`,
          }}
        >
          <Character
            name="Hùng"
            active={speaker === "Hùng"}
            walking={walking}
            thinking={thinks && speaker === "Hùng"}
            phase={1.7}
          />
        </div>
        <div
          style={{
            position: "absolute",
            left: positions[2],
            top: top + 2,
            scale: `${scale * 0.96}`,
            transformOrigin: "top left",
            translate: `${walking ? interpolate(frame, [0, 6 * fps], [-32, 16], { extrapolateRight: "clamp" }) : 0}px 0px`,
          }}
        >
          <Character
            name="Mai"
            active={speaker === "Mai"}
            walking={walking}
            thinking={thinks && speaker === "Mai"}
            phase={3.2}
          />
        </div>
      </div>
      {!intro && !outro && (
        <div
          style={{
            position: "absolute",
            left: 1330,
            top: 190,
            opacity: p,
            scale: interpolate(frame, [0, 0.4 * fps], [0.88, 1], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            }),
            transformOrigin: "bottom left",
          }}
        >
          <ScienceBubble mode={mode} />
        </div>
      )}
      {outro && (
        <div
          style={{
            position: "absolute",
            left: 1040,
            top: 145,
            width: 780,
            height: 565,
            background: "#285a5b",
            border: "14px solid #d4a272",
            borderRadius: 25,
            boxShadow: "10px 16px 0 #24403a25",
            padding: "45px 40px",
            color: "#fff8dc",
            opacity: p,
          }}
        >
          <div style={{ fontSize: 31, letterSpacing: 3, color: "#e8d4a6" }}>
            CÙNG SUY NGHĨ
          </div>
          <div
            style={{
              fontSize: 69,
              fontWeight: 700,
              lineHeight: 1.18,
              marginTop: 23,
            }}
          >
            Bạn Nam
            <br />
            đã đúng chưa?
          </div>
          <div style={{ display: "flex", gap: 18, marginTop: 28 }}>
            <div
              style={{
                border: "2px solid #c6e0d0",
                borderRadius: 13,
                padding: "13px 20px",
                fontSize: 32,
              }}
            >
              Nước biển
            </div>
            <div
              style={{
                border: "2px solid #c6e0d0",
                borderRadius: 13,
                padding: "13px 20px",
                fontSize: 32,
              }}
            >
              Nước lọc
            </div>
          </div>
          <div
            style={{
              fontSize: 31,
              lineHeight: 1.45,
              marginTop: 22,
              color: "#f6e8a1",
            }}
          >
            Chất tinh khiết hay hỗn hợp?
          </div>
        </div>
      )}
      <div
        style={{
          position: "absolute",
          left: 80,
          right: 80,
          bottom: 49,
          height: 218,
          background: "#fffdf3f2",
          border: "4px solid #36556a",
          borderRadius: 27,
          boxShadow: "0 10px 0 #24435428",
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 120,
          bottom: 242,
          padding: "9px 27px",
          borderRadius: 12,
          background: colors[speaker] || "#315766",
          color: "#fffaf0",
          fontSize: 30,
          fontWeight: 700,
          letterSpacing: 1,
        }}
      >
        {speaker}
      </div>
    </AbsoluteFill>
  );
};
