import { useCurrentFrame, useVideoConfig } from "remotion";
const ink = "#274459";
export const ScienceBubble = ({ mode }: { mode: string }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  const beach = mode === "beach";
  const salty = ["salt-question", "salt", "sea-mixture"].includes(mode);
  const float = mode === "float" || mode === "safety";
  const oxygen = mode === "oxygen";
  const bottle = mode === "bottle" || mode === "agree";
  const doubt = ["wonder", "doubt"].includes(mode);
  if (!beach && !salty && !float && !oxygen && !bottle && !doubt) return null;
  return (
    <svg
      width="550"
      height="525"
      viewBox="0 0 550 525"
      style={{ overflow: "visible", fontFamily: "Classroom" }}
    >
      <path
        d="M54 37Q-1 50 17 117Q-9 165 27 208Q1 277 45 315Q29 375 100 393L444 395Q521 386 513 326Q556 272 520 219Q553 151 516 106Q526 42 463 32Z"
        fill="#fffdf5"
        fillOpacity=".97"
        stroke={ink}
        strokeWidth="4"
      />
      <circle
        cx="38"
        cy="419"
        r="15"
        fill="#fffdf5"
        stroke={ink}
        strokeWidth="3"
      />
      <circle
        cx="12"
        cy="448"
        r="8"
        fill="#fffdf5"
        stroke={ink}
        strokeWidth="2.5"
      />
      {beach && (
        <>
          <path d="M64 105H469V304H64Z" fill="#d8f1ee" stroke="none" />
          <circle cx="406" cy="130" r="32" fill="#ffd170" />
          <path d="M65 213Q160 190 272 213T468 212V304H65Z" fill="#53bfce" />
          <path
            d={`M65 ${243 + Math.sin(t * 2) * 5}Q160 222 272 242T468 241`}
            fill="none"
            stroke="#ecfffb"
            strokeWidth="6"
          />
          <path
            d={`M65 ${278 + Math.sin(t * 2.5) * 4}Q180 253 285 279T468 277`}
            fill="none"
            stroke="#dcf8ee"
            strokeWidth="4"
          />
          <path
            d="M65 296Q230 268 468 300V334H65Z"
            fill="#f2d49c"
            stroke="none"
          />
          <path
            d="M134 288L157 175M111 193Q157 155 193 180M115 170Q152 158 184 149M148 149Q157 155 163 181"
            fill="none"
            stroke="#38866d"
            strokeWidth="11"
          />
          <text
            x="274"
            y="95"
            textAnchor="middle"
            fontSize="36"
            fontWeight="700"
            fill={ink}
          >
            MỘT NGÀY Ở BIỂN
          </text>
        </>
      )}
      {salty && (
        <>
          <text
            x="272"
            y="105"
            textAnchor="middle"
            fontSize="43"
            fontWeight="700"
            fill={ink}
          >
            {mode === "salt-question" ? "VÌ SAO MẶN?" : "TRONG NƯỚC BIỂN"}
          </text>
          <path
            d="M85 160L112 320Q273 354 433 320L460 160"
            fill="#b8e4e9"
            stroke={ink}
            strokeWidth="4"
          />
          <path
            d={`M93 210Q179 ${190 + Math.sin(t * 2) * 6} 274 211T451 209L434 319Q272 348 112 319Z`}
            fill="#58b9cb"
            opacity=".75"
          />
          {[0, 1, 2, 3, 4].map((i) => (
            <g
              key={i}
              transform={`translate(${155 + i * 57} ${249 + Math.sin(t * 2 + i) * 17}) rotate(${i * 17 + t * 8})`}
            >
              <circle
                r="7"
                fill="#fffef5"
                fillOpacity=".85"
                stroke="#91b9c2"
                strokeWidth="1.5"
              />
              <circle
                cx="11"
                cy="10"
                r="3"
                fill="#edffff"
                fillOpacity=".75"
                stroke="none"
              />
            </g>
          ))}
          <text x="273" y="382" textAnchor="middle" fontSize="34" fill={ink}>
            {mode === "sea-mixture"
              ? "Nước + muối + chất khác"
              : "Muối hòa tan trong nước"}
          </text>
        </>
      )}
      {float && (
        <>
          <text
            x="273"
            y="96"
            textAnchor="middle"
            fontSize="41"
            fontWeight="700"
            fill={ink}
          >
            {mode === "safety" ? "CẦN NHỚ" : "BIỂN CHẾT"}
          </text>
          <path
            d="M65 225Q160 204 270 225T470 223V331H65Z"
            fill="#8dcfd9"
            stroke="none"
          />
          <g transform={`translate(273 ${220 + Math.sin(t * 2.5) * 9})`}>
            <ellipse
              rx="86"
              ry="57"
              fill="#fff9e8"
              stroke="#d57862"
              strokeWidth="20"
            />
            <ellipse
              rx="39"
              ry="25"
              fill="#b5e4e8"
              stroke="#3c7887"
              strokeWidth="3"
            />
            <path
              d="M-73-24L-44-12M-73 25L-44 14M73-24L44-12M73 25L44 14"
              stroke="#d57862"
              strokeWidth="19"
            />
          </g>
          {mode === "float" ? (
            <>
              <text
                x="273"
                y="150"
                textAnchor="middle"
                fontSize="32"
                fill={ink}
              >
                Độ mặn cao → dễ nổi hơn
              </text>
              <text
                x="273"
                y="377"
                textAnchor="middle"
                fontSize="30"
                fill={ink}
              >
                Biển Chết là một hồ nước mặn.
              </text>
            </>
          ) : (
            <>
              <text
                x="273"
                y="146"
                textAnchor="middle"
                fontSize="31"
                fill={ink}
              >
                Dễ nổi hơn ≠ an toàn tuyệt đối
              </text>
              <text
                x="273"
                y="359"
                textAnchor="middle"
                fontSize="30"
                fontWeight="700"
                fill="#a24e43"
              >
                Vẫn có nguy cơ đuối nước.
              </text>
            </>
          )}
        </>
      )}
      {oxygen && (
        <>
          <text
            x="275"
            y="98"
            textAnchor="middle"
            fontSize="42"
            fontWeight="700"
            fill={ink}
          >
            CÒN CHẤT NÀO KHÁC?
          </text>
          <path
            d="M64 165Q153 146 277 166T477 165V338H64Z"
            fill="#b8e4e9"
            stroke="none"
          />
          <g transform={`translate(${218 + Math.sin(t) * 25} 263)`}>
            <path
              d="M-70 0Q-5-64 59 0Q-5 62-70 0L-112-38V38Z"
              fill="#edb06b"
              stroke={ink}
              strokeWidth="3"
            />
            <circle cx="26" cy="-7" r="5" fill={ink} />
            <path
              d="M-7-17L-26 0L-8 18"
              fill="none"
              stroke="#d37e55"
              strokeWidth="3"
            />
          </g>
          {[0, 1, 2].map((i) => (
            <circle
              key={i}
              cx={350 + i * 30}
              cy={290 - ((t * 36 + i * 48) % 136)}
              r={9 + i * 2}
              fill="#f7ffff"
              fillOpacity=".6"
              stroke="#67a9ba"
              strokeWidth="2"
            />
          ))}
          <text x="273" y="377" textAnchor="middle" fontSize="37" fill={ink}>
            O₂ hòa tan → hô hấp
          </text>
        </>
      )}
      {bottle && (
        <>
          <text
            x="274"
            y="96"
            textAnchor="middle"
            fontSize="34"
            fontWeight="700"
            fill={ink}
          >
            Ý KIẾN CỦA NAM
          </text>
          <g transform="translate(202 127)">
            <rect
              x="40"
              y="0"
              width="53"
              height="23"
              rx="4"
              fill="#4ca7ba"
              stroke={ink}
              strokeWidth="3"
            />
            <path
              d="M42 22H91V40L110 64V192Q65 209 20 192V64L42 40Z"
              fill="#cff0ef"
              stroke={ink}
              strokeWidth="3"
            />
            <path
              d="M23 112Q65 100 107 112V190Q65 205 23 190Z"
              fill="#91d4e1"
              stroke="none"
            />
            <rect
              x="21"
              y="110"
              width="88"
              height="49"
              fill="#fff7dc"
              stroke="none"
            />
            <path
              d="M60 115Q36 139 64 151Q92 138 60 115"
              fill="#3b9fb4"
              stroke="none"
            />
            <path d="M36 68V100" stroke="white" strokeWidth="6" />
          </g>
          <text
            x="382"
            y="249"
            textAnchor="middle"
            fontSize="114"
            fontWeight="700"
            fill="#c9854e"
            transform={`rotate(${Math.sin(t * 2) * 5} 382 249)`}
          >
            ?
          </text>
          <text x="274" y="381" textAnchor="middle" fontSize="30" fill={ink}>
            Nước lọc = nước nguyên chất?
          </text>
        </>
      )}
      {doubt && (
        <>
          <text
            x="275"
            y="117"
            textAnchor="middle"
            fontSize="40"
            fontWeight="700"
            fill={ink}
          >
            {mode === "wonder" ? "THẬT THÚ VỊ!" : "CÓ CHẮC KHÔNG?"}
          </text>
          <text
            x="275"
            y="308"
            textAnchor="middle"
            fontSize="174"
            fontWeight="700"
            fill={mode === "wonder" ? "#d4a155" : "#8b7ca3"}
            transform={`rotate(${Math.sin(t * 2) * 5} 275 240)`}
          >
            {mode === "wonder" ? "✦" : "?"}
          </text>
          <text x="275" y="380" textAnchor="middle" fontSize="28" fill={ink}>
            {mode === "wonder"
              ? "Một câu chuyện đáng khám phá."
              : "Cùng kiểm tra lại suy nghĩ nhé!"}
          </text>
        </>
      )}
    </svg>
  );
};
